from base import Database

def query1():
    query = f"""SELECT name FROM city WHERE city_id IN 
    (SELECT city_id FROM address WHERE address_id IN(SELECT 
    address_id FROM staff WHERE first_name='dilshod'));"""

    z = Database.getall("localhost", "dorixona", 'postgres', '23042005.o', query)
    for i in z:
        print(i)

def query2():
    query = f"""SELECT name,count,price,
            dorixona_product.dorixona_id
            FROM product 
            LEFT JOIN dorixona_product ON 
            product.product_id = dorixona_product.product_id ;"""
    z = Database.getall("localhost", "dorixona", 'postgres', '23042005.o', query)
    for i in z:
        print(i)

def sum():
    query = " SELECT sum(price) FROM product;"
    z = Database.getall("localhost", "dorixona", 'postgres', '23042005.o', query)
    for i in range(len(z)):
        print(z[i][i])

if __name__ == "__main__":
    query1()

