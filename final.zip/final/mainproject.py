import json
import function
import admin_page
import user_page
from homeproject import super_admin
import models

def main():
    """login va parol kiritish"""

    username = input("username: ")
    password = input("password: ")
    with open("super_ad.json", "r") as fil:
        dat = json.load(fil)
        for i in dat["super"]:
            if i["username"] == username and i["password"] == password:
                if i["status"] == 2:
                    return super_admin.super_admin(username, password)
    with open("users.json", "r") as file:
        data = json.load(file)
        for i in data["users"]:
            if i["username"] == username and i["password"] == password:
                if i["status"] == 1:
                    return admin_page.admin_p(username, password)
                elif i["status"] == 0:
                    return user_page.user_p(username, password)
        print("parol yoki foydalanuvhi nomi xato")
    return replay()
def replay():
    """Takror urinish"""

    print(f"""
        1.Ro'yxatdan o'tmoqchimisiz
        2.Qayta kiritish""")
    ls = int(input("= "))
    if ls == 1:
        return function.new_user()
    elif ls == 2:
        return main()

def start():
    """tizimga kirish"""

    print(f"""   Xush kelibsiz!
        1.Tizimga kirish
        2.Ro'yxatdan o'tish""")

    l = int(input("= "))

    if l == 1:
        return main()
    elif l == 2:
        return function.new_user()
    else:
        return replay()



if __name__ == "__main__":
    start()
