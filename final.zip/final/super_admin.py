import json
from datetime import datetime
import os
import function
import models

def super_admin(username,password):

    """super admin sahifasi"""

    print("Super admin sahifasi")
    menu = input("""
    1.Kurslar ro'yxati
    2.Foydalanuvchilar 
    3.Yangi kurs qoshish
    4.Kursni o'chirish
    5.yangi foydalanuvchi qoshish
    6.userni ochirish
    7.Profil malumotlari
    8.chiqish
    """)

    if menu == '1':
        return function.kurslara(username, password)
    elif menu == '2':
        return function.users(username, password)
    elif menu == '3':
        return function.add_kurs(username, password)
    elif menu == '4':
        return function.del_kurs(username, password)
    elif menu == '5':
        return function.add_user(username, password)
    elif menu == '6':
        return function.del_user(username, password)
    elif menu == '7':
        return function.profil(username, password)
    elif menu == '8':
        return function.logout(username, password)
    else :
        print("bunday buyruq yo'q qayta kiriting")
        return super_admin(username, password)

