import json
import os

from homeproject import super_admin
from mainproject import main
import admin_page
import user_page
import models

def check_U(username, password):
    back = input("Ortga qaytish: (back)")
    while back != "back":
        os.system("color 6")
        print("Bunday buyruq mavjud emas namunaga etibor bering")
        back = input("Orqaga qaytish: (back)")
    if back == "back":
        os.system("color 3")
        os.system("cls")
        return user_page.user_p(username, password)

def check_ad(username, password):
    back = input("Ortga qaytish: (back)")
    while back != "back":
        os.system("color 6")
        print("Bunday buyruq mavjud emas namunaga etibor bering")
        back = input("Orqaga qaytish: (back)")
    if back == "back":
        os.system("color 3")
        os.system("cls")
    with open("super_ad.json", "r") as fil:
        dat = json.load(fil)
        for i in dat["super"]:
            if i["username"] == username and i["password"] == password:
                if i["status"] == 2:
                    return super_admin.super_admin(username, password)
    with open("users.json", "r") as file:
        data = json.load(file)
        for i in data["users"]:
            if i["username"] == username and i["password"] == password:
                if i["status"] == 1:
                    return admin_page.admin_p(username, password)


def check_s(username, password):
    back = input("Ortga qaytish: (back)")

    while back != "back":
        os.system("color 6")
        print("Bunday buyruq mavjud emas namunaga etibor bering")
        back = input("Orqaga qaytish: (back)")

    if back == "back":
        os.system("color 3")
        os.system("cls")
        return super_admin.super_admin(username, password)



def users(username, password):

    """userlarni korish"""

    print("Sayt foydalanuvchilari :")
    with open("users.json", "r") as file:
        data = json.load(file)
        for i in data["users"]:
            print(i["firstname"], i["lastname"])

    check_ad(username, password)


def kurslara(username, password):

    """admin uchun kurslar royxati"""

    with open("kurs.json", 'r') as file:
        data = json.load(file)
        print("Kurslar ro'yxati: ")

        for course in data['course']:
            print(f"""
                name: {course['name']}
                izoh: {course['description']}
                modullar: {course['modules_count']}
                narxi: {course['price']}
                talabalar: {course['active_students']}
                yaratildi: {course['create_date']}
                foydalanuvchilar: {course['users']}
                    """)

    check_ad(username, password)

def kurslarf(username, password):

    """user uchun kurslar"""

    with open("kurs.json", 'r') as file:
        data = json.load(file)
        print("   Kurslar ro'yxati: ")
        for course in data['course']:
            print(f"name: {course['name']}\nizoh: {course['description']}\nmodullar: {course['modules_count']}\nnarxi: {course['price']}\nyaratildi: {course['create_date']}\nfoydalanuvchilar:{course['users']}")

    check_U(username, password)

def add_kurs(username, password):
    """yangi kurs qoshish"""

    # l = [username, password]
    name = input("nomi:")
    name = name.lower()

    with open("kurs.json", 'r') as file:
        data = json.load(file)

    for i in data['course']:
        if i["name"] == name:
            print("bunday kurs mavjud boshqa kurs kiritasizmi")
            m = input("ha/yoq")
            m = m.lower()
            if m == "ha":
                return add_kurs(username, password)
            elif m == "yoq":
                return check_ad(username, password)

    description = input("izohi:")
    modules_count = input("modullar:")
    price = int(input("narxi:"))
    active_students = 0
    curs = models.Courses(name, description, modules_count, price, active_students)
    curs.save()

    check_ad(username, password)

def del_kurs(username, password):
    with open("kurs.json", "r") as f:
        dat = json.load(f)
        print("kurslar royxati:")
    z = dat['course']
    for i in range(len(dat['course'])):
        print(1 + i, z[i]["name"], ":", z[i]["price"])
    name = int(input("ochirishni istagan kurs raqamini kiriting : "))
    ls = []
    for i in range(len(z)):
        ls.append(i + 1)
    if name in ls:
        dat["course"].pop(name - 1)
        print("o'chirildi")
        with open("kurs.json", "w") as file:
            json.dump(dat, file, indent=6)
    elif name is not ls:
        print("bunday raqamda kurs yo'q\nqayta kiritasizmi:")
        n = input("(ha/yoq)   :")
        n = n.lower()
        if n == "ha":
            return del_kurs(username, password)
        else:
            check_s(username, password)

    check_s(username, password)


def add_member(username, password):
    """kursga yozilish"""
    x = 0
    with open("kurs.json", "r") as f:
        dat = json.load(f)
        print("kurslar royxati:")
    z = dat['course']
    for i in range(len(dat['course'])):
        print(1+i, z[i]["name"], ":", z[i]["price"])

    with open("users.json", "r") as file:
        data = json.load(file)

        for i in data["users"]:

            if i["username"] == username and i["password"] == password:
                x = int(i["balance"])
                print("hisobingizda:", x)
    ls = []
    for i in range(len(z)):
        ls.append(i+1)
    nom = int(input("kurs raqamini kiriting:"))

    if nom in ls:
        x = x - int(dat['course'][nom-1]["price"])

    if x >= 0:
        dat['course'][nom-1]["active_students"] = int(dat['course'][nom-1]["active_students"]) + 1
        dat['course'][nom-1]['users'].append(username)
        print("kursga qoshildingiz")

    elif x < 0:
        print("hisobingizda mablag' kam")

    with open("kurs.json", "w") as file:
        json.dump(dat, file, indent=6)

    with open("users.json", "r") as file:
        data = json.load(file)

        for i in data["users"]:

            if i["username"] == username and i["password"] == password:
                if x > 0:
                    i["balance"] = x

    with open("users.json", "w") as file:
        json.dump(data, file, indent=6)

    check_U(username, password)
def add_user(username, password):
    """yangi user qoshish"""

    user_name = input("username:")
    with open("users.json", "r") as file:
        data = json.load(file)
    zi = data["users"]
    with open("super_ad.json", "r") as fil:
        dat = json.load(fil)
    li = dat["super"][0]["username"]
    for i in zi:
        if i["username"] == user_name or user_name == li:
            print("bunday username mavjud boshqa kiriting:")
            return add_user(username, password)
    pass_word = input("paroli:")

    firstname = input("ismi:")
    lastname = input("familiyasi:")
    m = models.User.read(username, password)
    if m == 1:
        status = 0
    elif m == 2:
        print("""lavozimi:
        1.Foydalanuvchi
        2.Admin
        3.Super admin""")
        l = int(input("raqamni kiriting:"))
        if l <= 3:
            status = l-1
        else:
            print("qo'pol xato")
            return add_user(username, password)
    balance = int(input("mablag'i:"))
    z = models.User(firstname, lastname, user_name, pass_word, status, balance)
    z.save()

    check_ad(username, password)


def note(username, password):
    print("bunday raqamda user yo'q\nqayta kiritasizmi:")
    n = input("(ha/yoq)   :")
    n = n.lower()
    if n == "ha":
        return del_user(username, password)
    elif n == "yoq":
        return check_s(username, password)
    else:
        print("kiritilgan izohlarga amal qiling")


def del_user(username, password):
    with open("users.json", "r") as f:
        dat = json.load(f)
        print("userlar royxati:")
    z = dat['users']
    for i in range(len(z)):
        if z[i]["username"] != username and z[i]["password"] != password:
            print(i+1, ".", z[i]["firstname"], z[i]["lastname"])
    name = int(input("ochirishni istagan user raqamini kiriting : "))
    name = name-1
    ls = []
    for i in range(len(z)):
        ls.append(i + 1)
    if name in ls:
        dat["users"].pop(name)
        print("o'chirildi")
        with open("users.json", "w") as file:
            json.dump(dat, file, indent=6)
    elif name is not ls:
        return note(username, password)
    check_s(username, password)

def new_user():
    user_name = input("username:")
    with open("users.json", "r") as file:
        data = json.load(file)
    zi = data["users"]

    with open("super_ad.json", "r") as fil:
        dat = json.load(fil)
    li = dat["super"][0]["username"]
    for i in zi:
        if i["username"] == user_name or user_name == li:
            print("bunday username mavjud boshqa kiriting:")
            return new_user()
    pass_word = input("paroli:")
    firstname = input("ismi:")
    lastname = input("familiyasi:")

    a = models.Student(firstname, lastname, user_name, pass_word)
    a.saved()


def profil(username, password):

    """profil malumotlarini korish"""

    print("Profil malumotlari")
    with open("super_ad.json", "r") as fil:
        dat = json.load(fil)
        for i in dat["super"]:
            if i["username"] == username and i["password"] == str(password):
                print(f"ismi : {i['firstname']} \nfamiliyasi : {i['lastname']} \nusername : {i['username']} \npassword : {i['password']}\nmablagi={i['balance']}")

    with open("users.json", "r") as file:
        data = json.load(file)
        for i in data["users"]:
            if i["username"] == username and i["password"] == str(password):
                print(f"ismi : {i['firstname']} \nfamiliyasi : {i['lastname']} \nusername : {i['username']} \npassword : {i['password']}\nmablagi={i['balance']}")

    check_ad(username, password)
    check_U(username, password)

def maps(username, password):

    """filiallar joylashuvi"""

    with open("map.json", "r") as fl:
        z = json.load(fl)
        for i in z["filiallar"]:
            print(i["name"], "filiali\njoylashuvi:", i["location"])

    check_U(username, password)

def logout(username, password):
    """akkountdan chiqish"""
    username = False
    password = False
    return main()

