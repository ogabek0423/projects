import json
from datetime import datetime
import mainproject
class Courses:
    def __init__(self, name, description, modules_count, price, active_students, create_date=None):
        self.name = name.lower()
        self.description = description
        self.modules_count = modules_count
        self.price = price
        self.__active_students = active_students
        self.create_date = datetime.today()

    def get_modules_count(self):
        return self.modules_count

    def get_actives(self):
        return self.__active_students


    def save(self):
        new_course = {
            "name": self.name,
            "description": self.description,
            "modules_count": self.modules_count,
            "price": self.price,
            "active_students": self.__active_students,
            "create_date": f"{datetime.today()}",

        }
        with open("kurs.json") as file:
            data = json.load(file)
            data['course'].append(new_course)
        with open("kurs.json", "w") as f:
            json.dump(data, f, indent=6)
            print("muvaffaqiyatli qo'shildi")

    def __str__(self):
        return f"{self.name}{self.modules_count}{self.price}{self.create_date}{self.description}"

class User:
    def __init__(self, firstname, lastname, username, password, status, balance):
        self.firstname = firstname
        self.lastname = lastname
        self.username = username
        self.password = password
        self.status = status
        self.balance = balance

    def get_balance(self):
        return self.balance

    def get_status(self):
        return self.status
    @staticmethod
    def read(username, password):
        with open("users.json", "r")as file:
            data = json.load(file)
        s = data["users"]
        with open("super_ad.json", "r") as f:
            dat = json.load(f)
        c = dat["super"]
        for i in s:
            if username == i["username"] and password == i["password"]:
                return i["status"]
        for i in c:
            if username == i["username"] and password == i["password"]:
                return i["status"]
    def save(self):
        new_user = {
            "firstname": self.firstname,
            "lastname": self.lastname,
            "username": self.username,
            "password": self.password,
            "status": self.status,
            "balance": self.balance,

        }
        with open("users.json", "r") as file:
            data = json.load(file)
        data["users"].append(new_user)
        with open("users.json", "w") as f:
            json.dump(data, f, indent=6)
        print("muvaffaqiyatli qo'shildi")

    def __str__(self):
        return f"{self.firstname}{self.lastname}{self.username}{self.password}"


class Student(User):
    def __init__(self, firstname, lastname, username, password, status=0, balance=0):
        User.__init__(self, firstname, lastname, username, password, status, balance)

    def saved(self):
        new_user = {
            "firstname": self.firstname,
            "lastname": self.lastname,
            "username": self.username,
            "password": self.password,
            "status": self.status,
            "balance": self.balance,

        }
        with open("users.json", "r") as file:
            data = json.load(file)
        data["users"].append(new_user)

        with open("users.json", "w") as f:
            json.dump(data, f, indent=6)
        print("muvaffaqiyatli qo'shildingiz")
        return mainproject.start()
