from base import Database

def country():
    query = '''CREATE TABLE country(
    country_id  SERIAL PRIMARY KEY,
    name VARCHAR(30));'''

    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)

def city():
    query = '''CREATE TABLE city(
    city_id SERIAL PRIMARY KEY,
    name VARCHAR(30),
    country_id INT REFERENCES country(country_id));'''
    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)

def region():
    query = '''CREATE TABLE region(
    region_id SERIAL PRIMARY KEY,
    name VARCHAR(30),
    city_id INT REFERENCES city(city_id));'''
    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)

def distrc():
    query = '''CREATE TABLE district(
    district_id SERIAL PRIMARY KEY,
    name VARCHAR(40) NOT NULL,
    region_id INT REFERENCES region(region_id));'''
    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)

def inventory():
    query = '''CREATE TABLE inventory(
    inventory_id SERIAL PRIMARY KEY,
    district_id INT REFERENCES district(district_id),
    product_id INT REFERENCES product(product_id));'''
    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)

def staff():
    query = '''CREATE TABLE payment(
    payment_id SERIAL PRIMARY KEY,
    amount INT,
    pay_date DATE DEFAULT now(),
    user_id INT REFERENCES users(user_id),
    product_id INT REFERENCES product(product_id),
    staff_id INT REFERENCES staff(staff_id));'''

    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)

def category():
    query = '''CREATE TABLE category(
    category_id  SERIAL PRIMARY KEY,
    name VARCHAR(30));'''
    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)

def product():
    query = '''CREATE TABLE product(
    product_id SERIAL PRIMARY KEY,
    name VARCHAR(30),
    count INT DEFAULT 0,
    price INT,
    start_date DATE,
    end_date DATE,
    category_id INT REFERENCES category(category_id));'''
    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)

def user():
    query = '''CREATE TABLE users(
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(20),
    password VARCHAR(20),
    firstname VARCHAR(25),
    lastname VARCHAR(25),
    create_date DATE DEFAULT now(),
    district_id INT REFERENCES district(district_id));'''
    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)

def payment():
    query = f"""CREATE TABLE payment(
               payment_id SERIAL PRIMARY KEY,
               amount INT NOT NULL,
               user_id INT REFERENCES users(user_id),
               product_id INT REFERENCES product(product_id),
               staff_id INT REFERENCES staff(staff_id),
               pay_time DATE DEFAULT NOW());
               """
    Database.connect("localhost", "netstore", "postgres", "23042005.o", query)
