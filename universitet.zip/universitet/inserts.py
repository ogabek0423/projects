from connectdb import Database

def insert_city():
    a = ['BUXORO', 'TOSHKENT', 'FARGONA', 'NAMANGAN', 'SAMARQAND']
    for i in a:
        query = f"""INSERT INTO city(name)
                    VALUES('{i}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def insert_address():
    b = ['BUXORO', 'TOSHKENT', 'FARGONA', 'NAMANGAN', 'SAMARQAND']
    for i in range(len(b)):
        query = f"""INSERT INTO address(name,city_id)
                        VALUES('{b[i]}',{i+1});"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)


def insert_user():
    fam = ['ALISHEROV', 'MAHMUDOVA', 'RUSTAMOV', 'MURODOVA', 'ABDULLAYEV']
    ism = ['MAHMUD', 'MARJONA', 'ALISHER', 'MALIKA', 'SARDOR']
    age = [1996, 1997, 1998, 1999, 2000]
    status = 'oqituvchi'
    for i in range(len(fam)):
        query = f"""INSERT INTO users(first_name,last_name,birth_year,status,salary)
                        VALUES('{ism[i]}','{fam[i]}','{age[i]}','{status}',1000);"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def in_cont():
    name = ['rektor', 'dekan', 'kafedra mudiri', 'katta oqituvchi', 'oqituvchi', 'asistent', 'tashkiliy ishlar rektor orinb', 'qorovul', 'farrosh']
    for i in name:
        query = f"""INSERT INTO control(name) VALUES('{i}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def in_fak():
    fac = ["KIF", 'DIF', 'AKT', 'KXF', 'MOLIYA', 'TELEKOMUNIKATSIYA']
    for i in fac:
        query = f"""INSERT INTO fakultet(name) VALUES('{i}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def teachsub():
    a = [1, 2, 3, 4, 5]
    b = [1, 2, 3, 4, 5]
    for i in range(len(a)):
        query = f"""INSERT INTO teach_sub(teacher_id,sub_id) VALUES('{a[i]}','{b[4 - i]}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)


def sub_fac():
    a = [1, 2, 3, 4, 5]
    b = [1, 2, 3, 4, 5]
    for i in range(len(a)):
        query = f"""INSERT INTO sub_fac(sub_id,fakultet_id) VALUES('{a[4-i]}','{b[i]}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)


def in_subject():
    subs = ["DISKRET", 'ELEKTRONIKA', 'KIBERXAVFSIZLIK', 'MTVAA', 'WDA']
    for i in range(len(subs)):
        query = f"""INSERT INTO subject(name,kredit,teacher_id) VALUES('{subs[i]}',6,{i+1});"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def gr():
    n = [310, 311, 312, 313, 314]
    for i in range(len(n)):
        query = f"""INSERT INTO groups(name , student_count, fakultet_id) VALUES('{str(n[i])}',25,'{i+1}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def user_con():
    a = [1, 2, 3, 4, 5]
    b = [1, 2, 3, 4, 5]
    for i in range(len(a)):
        query = f"""INSERT INTO user_cont(teacher_id,cont_id) VALUES('{a[i]}','{b[i]}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def inteachfak():
    a = [1, 2, 3, 4, 5]
    b = [1, 2, 3, 4, 5]
    for i in range(len(a)):
        query = f"""INSERT INTO teach_fac(teacher_id,fakultet_id) VALUES('{a[i]}','{b[4-i]}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def spec():
    specs = ['dasturchi', 'biznesmen', 'telekomunikatsiya lohilari', 'video montaj', 'elektr qurilmalar mutaxasisi']
    for i in range(len(specs)):
        query = f"""INSERT INTO specs(type) VALUES('{specs[i]}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def student():
    ism = ['OGABEK', 'JAVLON', 'DOSTON', 'UMID', 'OZOD']
    fam = ['OBIDOV', 'HAMIDOV', 'ADIZOV', 'AMONOV', 'ISTAMOV']
    year = [2005, 2004, 2004, 2004, 2004]
    id = [1, 2, 3, 4, 5]
    for i in range(len(id)):
        query = f"""INSERT INTO students(first_name,last_name,birth_year,gender,address_id,specs_id,group_id) VALUES('{ism[i]}','{fam[i]}','{year[i]}','erkak',6,'{id[i]}','{id[i]}');"""
        Database.connect("localhost", "universitet", "postgres", "23042005.o", query)





if __name__ == "__main__":
    teachsub()
