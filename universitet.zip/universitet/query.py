from connectdb import Database

def query1():
    query = f"""SELECT name FROM city WHERE city_id IN 
    (SELECT city_id FROM address WHERE address_id IN(SELECT 
    address_id FROM students WHERE first_name='OGABEK'));"""

    z = Database.getall("localhost", "universitet", 'postgres', '23042005.o', query)
    for i in z:
        print(i)


def query2():
    query = f"""SELECT first_name,last_name,
            user_cont.cont_id
            FROM  users
            LEFT JOIN user_cont ON 
            users.teacher_id = user_cont.teacher_id;"""
    z = Database.getall("localhost", "universitet", 'postgres', '23042005.o', query)
    for i in z:
        print(i)


def sum():
    query = " SELECT AVG(student_count) FROM groups;"
    z = Database.getall("localhost", "universitet", 'postgres', '23042005.o', query)
    for i in range(len(z)):
        print(z[i][i])


if __name__ == "__main__":
    query2()

