from connectdb import Database

def users():
    query = f"""CREATE TABLE users(
    teacher_id SERIAL PRIMARY KEY,
    first_name VARCHAR(40) NOT NULL,
    last_name VARCHAR(40) NOT NULL,
    birth_year INT NOT NULL,
    status VARCHAR(20),
    salary INT,
    gender VARCHAR(10),
    username VARCHAR(20),
    password VARCHAR(20),
    phone VARCHAR(20));
"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def fakultet():
    query = f"""CREATE TABLE fakultet(
    fakultet_id SERIAL PRIMARY KEY,
name VARCHAR(30),
create_date DATE DEFAULT NOW(),
description TEXT);"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def groups():
    query = f"""CREATE TABLE groups(
    group_id SERIAL PRIMARY KEY,
name VARCHAR(20),
student_count INT,
fakultet_id INT REFERENCES fakultet(fakultet_id));
"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def subject():
    query = f"""CREATE TABLE subject(
sub_id SERIAL PRIMARY KEY,
name VARCHAR(25),
kredit INT,
teacher_id INT REFERENCES users(teacher_id),
create_date DATE DEFAULT NOW());"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def subfak():
    query = f"""CREATE TABLE sub_fac(
sub_id INT REFERENCES subject(sub_id),
fakultet_id INT REFERENCES fakultet(fakultet_id));"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def teach_sub():
    query = f"""CREATE TABLE teach_sub(
    sub_id INT REFERENCES subject(sub_id),
    teacher_id INT REFERENCES users(teacher_id));
"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def teach_fac():
    query = f"""CREATE TABLE teach_fac(
        sub_id INT REFERENCES subject(sub_id),
        fakultet_id INT REFERENCES fakultet(fakultet_id));
    """
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def specs():
    query = f"""CREATE TABLE specs(
        spec_id SERIAL PRIMARY KEY,
    type VARCHAR(30),
    create_date DATE DEFAULT NOW(),
    description TEXT);"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def city():
    query = f"""CREATE TABLE city(
    city_id SERIAL PRIMARY KEY,
    name VARCHAR(30) NOT NULL,
    last_update DATE DEFAULT now());
"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)


def address():
    query = f"""CREATE TABLE address(
    address_id SERIAL PRIMARY KEY,
    name VARCHAR(30) NOT NULL,
    city_id INT REFERENCES city(city_id),
    last_update DATE DEFAULT now());
"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)


def student():
    query = f"""CREATE TABLE students(
        student_id SERIAL PRIMARY KEY,
        first_name VARCHAR(40) NOT NULL,
        last_name VARCHAR(40) NOT NULL,
        birth_year INT NOT NULL,
        gender VARCHAR(10),
        address_id INT REFERENCES address(address_id),
        phone VARCHAR(20),
        specs_id INT REFERENCES specs(spec_id),
        group_id INT REFERENCES groups(group_id));
        
    """
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def cont():
    query = f"""CREATE TABLE control(
        control_id SERIAL PRIMARY KEY,
    name VARCHAR(30));"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

def user_cont():
    query = f"""CREATE TABLE user_cont(
    teacher_id INT REFERENCES users(teacher_id),
    cont_id INT REFERENCES control(control_id)
    );"""
    Database.connect("localhost", "universitet", "postgres", "23042005.o", query)

if __name__ == "__main__":
    user_cont()
